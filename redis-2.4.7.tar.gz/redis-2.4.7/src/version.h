#define REDIS_VERSION "2.4.7"
